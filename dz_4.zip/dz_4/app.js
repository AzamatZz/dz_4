function replace(number, replacer, dnr) {
    let array = Array.from(number); 
    if (dnr >= 0)
        for (let i = 0; i < number.length - dnr; i++)
            array[i] = replacer;
    else
        for (let i = -dnr; i < array.length; i++)
            array[i] = replacer;
    return array.join(""); 
}
console.log(replace('+996555658864', '*', -11));

function countChars(str, symbol) {
    let result = {};
    let chars = str.split("");
    for (let i = 0; i < chars.length; i++) {
      let count = result[chars[i]]? result[chars[i]] : 0;
      result[chars[i]] = count + 1; 
      let symbol
    }
    return result;
  }
  
  console.log(countChars("Azamat"));
